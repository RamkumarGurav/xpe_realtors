<?php

echo "<pre> <br>";
print_r("test1");
exit;

?>