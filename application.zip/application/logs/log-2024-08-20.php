<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-20 11:32:20 --> Severity: Notice --> Undefined property: stdClass::$module_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Property_sub_type_module\view.php 33
ERROR - 2024-08-20 11:44:36 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 11:44:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:06:43 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:06:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:06:52 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:06:52 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:07:02 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:07:05 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:07:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:12:03 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:18:56 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:18:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:21:14 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:43:07 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:45:14 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:45:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:48:51 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 91
ERROR - 2024-08-20 12:48:51 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 95
ERROR - 2024-08-20 12:48:51 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 96
ERROR - 2024-08-20 12:48:51 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 91
ERROR - 2024-08-20 12:48:51 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 95
ERROR - 2024-08-20 12:48:51 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 96
ERROR - 2024-08-20 12:48:51 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 188
ERROR - 2024-08-20 12:48:51 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 192
ERROR - 2024-08-20 12:49:43 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 91
ERROR - 2024-08-20 12:49:43 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 95
ERROR - 2024-08-20 12:49:43 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 96
ERROR - 2024-08-20 12:49:43 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 91
ERROR - 2024-08-20 12:49:43 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 95
ERROR - 2024-08-20 12:49:43 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 96
ERROR - 2024-08-20 12:49:43 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 188
ERROR - 2024-08-20 12:49:43 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 192
ERROR - 2024-08-20 12:49:58 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 91
ERROR - 2024-08-20 12:49:58 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 95
ERROR - 2024-08-20 12:49:58 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 96
ERROR - 2024-08-20 12:49:58 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 91
ERROR - 2024-08-20 12:49:58 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 95
ERROR - 2024-08-20 12:49:58 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 96
ERROR - 2024-08-20 12:49:58 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 188
ERROR - 2024-08-20 12:49:58 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 192
ERROR - 2024-08-20 12:50:04 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:50:04 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:54:09 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:58:55 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 12:58:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:04:36 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:04:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:04:42 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:09:08 --> Severity: Notice --> Undefined property: stdClass::$property_sub_type_id_prop E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\template\add_input_fields.php 211
ERROR - 2024-08-20 13:09:08 --> Severity: Notice --> Undefined property: stdClass::$property_sub_type_id_prop E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\template\add_input_fields.php 222
ERROR - 2024-08-20 13:18:12 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:18:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:24:00 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:24:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:24:21 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:24:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:44:12 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:49:35 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:52:02 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:52:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:57:48 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:57:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:58:56 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 13:58:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:02:32 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:02:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:48:07 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:48:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:52:52 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:52:52 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:57:27 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:58:02 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:58:14 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:58:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:59:42 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 14:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:03:29 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:03:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:06:56 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:06:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:09:41 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:10:08 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:10:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:10:38 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:10:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:13:59 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:14:20 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:14:20 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:16:53 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:16:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:18:10 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:18:10 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:19:07 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:19:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:19:59 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:19:59 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:20:24 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:20:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:20:44 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:20:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:27:06 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:27:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:27:29 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:27:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:38:03 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:38:03 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:47:05 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:47:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 15:47:59 --> Severity: error --> Exception: Too few arguments to function Login::reset_password(), 0 passed in E:\xampp\htdocs\xampp\MARS\pe_realtors\system\core\CodeIgniter.php on line 533 and exactly 1 expected E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\secureRegions\Login.php 262
ERROR - 2024-08-20 15:48:19 --> Severity: error --> Exception: Too few arguments to function Login::reset_password(), 0 passed in E:\xampp\htdocs\xampp\MARS\pe_realtors\system\core\CodeIgniter.php on line 533 and exactly 1 expected E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\secureRegions\Login.php 262
ERROR - 2024-08-20 15:51:53 --> Severity: Notice --> Undefined index: enquiry_input_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\models\Common_model.php 365
ERROR - 2024-08-20 15:55:34 --> Severity: error --> Exception: Too few arguments to function Login::reset_password(), 0 passed in E:\xampp\htdocs\xampp\MARS\pe_realtors\system\core\CodeIgniter.php on line 533 and exactly 1 expected E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\secureRegions\Login.php 262
ERROR - 2024-08-20 15:55:38 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\secureRegions\Login.php 278
ERROR - 2024-08-20 15:55:38 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\secureRegions\Login.php 278
ERROR - 2024-08-20 15:55:38 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\secureRegions\Login.php 279
ERROR - 2024-08-20 15:55:38 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\secureRegions\Login.php 279
ERROR - 2024-08-20 15:55:38 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\reset_password.php 59
ERROR - 2024-08-20 15:55:38 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\reset_password.php 59
ERROR - 2024-08-20 15:56:14 --> Severity: error --> Exception: Too few arguments to function Login::reset_password(), 0 passed in E:\xampp\htdocs\xampp\MARS\pe_realtors\system\core\CodeIgniter.php on line 533 and exactly 1 expected E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\secureRegions\Login.php 262
ERROR - 2024-08-20 16:19:54 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 16:19:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 16:31:07 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 16:31:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 16:35:56 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 16:35:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 16:37:03 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 16:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 16:52:43 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 16:52:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 17:29:10 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 17:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 17:29:43 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-20 17:29:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
