<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-19 10:28:15 --> Severity: Notice --> Undefined property: stdClass::$admin_user_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\inc\header.php 196
ERROR - 2024-08-19 10:28:15 --> Severity: Notice --> Undefined property: stdClass::$admin_user_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\inc\header.php 212
ERROR - 2024-08-19 10:30:54 --> Query error: Unknown column 'state_id' in 'where clause' - Invalid query: SELECT *
FROM `state`
WHERE (`state_id` >0)
ORDER BY `state_name` ASC
ERROR - 2024-08-19 10:31:26 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 10:31:26 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 10:31:26 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 10:31:28 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 90
ERROR - 2024-08-19 10:31:28 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 94
ERROR - 2024-08-19 10:31:28 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 95
ERROR - 2024-08-19 10:31:35 --> Query error: Unknown column 's.state_id' in 'on clause' - Invalid query: SELECT count(ft.id) as counts
FROM `location` as `ft`
JOIN `state` as `s` ON `s`.`state_id` = `ft`.`state_id`
JOIN `city` as `ci` ON `ci`.`city_id` = `ft`.`city_id`
ORDER BY `ft`.`location_id` desc
ERROR - 2024-08-19 10:39:36 --> Query error: Unknown column 'state_id' in 'where clause' - Invalid query: SELECT *
FROM `state`
WHERE (`state_id` >0)
ORDER BY `state_name` ASC
ERROR - 2024-08-19 10:39:59 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 10:39:59 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 10:39:59 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 10:55:42 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 10:55:42 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 10:55:42 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 10:55:44 --> Severity: Notice --> Undefined property: stdClass::$module_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\view.php 38
ERROR - 2024-08-19 10:56:48 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\edit.php 90
ERROR - 2024-08-19 10:56:48 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\edit.php 94
ERROR - 2024-08-19 10:56:48 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\edit.php 95
ERROR - 2024-08-19 10:56:51 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 10:56:51 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 10:56:51 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 10:56:56 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\edit.php 90
ERROR - 2024-08-19 10:56:56 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\edit.php 94
ERROR - 2024-08-19 10:56:56 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\edit.php 95
ERROR - 2024-08-19 10:56:59 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 10:56:59 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 10:56:59 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 10:57:01 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 88
ERROR - 2024-08-19 10:57:01 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 92
ERROR - 2024-08-19 10:57:01 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 93
ERROR - 2024-08-19 10:57:01 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 181
ERROR - 2024-08-19 10:57:01 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 185
ERROR - 2024-08-19 10:57:06 --> Query error: Unknown column 'country_id' in 'where clause' - Invalid query: SELECT *
FROM `country`
WHERE (`country_id` >0)
ORDER BY `name` ASC
ERROR - 2024-08-19 11:00:05 --> Query error: Unknown column 'country_id' in 'where clause' - Invalid query: SELECT *
FROM `country`
WHERE (`country_id` >0)
ORDER BY `name` ASC
ERROR - 2024-08-19 11:00:06 --> Query error: Unknown column 'country_id' in 'where clause' - Invalid query: SELECT *
FROM `country`
WHERE (`country_id` >0)
ORDER BY `name` ASC
ERROR - 2024-08-19 11:00:11 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 88
ERROR - 2024-08-19 11:00:11 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 92
ERROR - 2024-08-19 11:00:11 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 93
ERROR - 2024-08-19 11:00:11 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 181
ERROR - 2024-08-19 11:00:11 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 185
ERROR - 2024-08-19 11:00:15 --> Query error: Unknown column 'country_id' in 'where clause' - Invalid query: SELECT *
FROM `country`
WHERE (`country_id` >0)
ORDER BY `name` ASC
ERROR - 2024-08-19 11:01:29 --> Query error: Unknown column 'country_id' in 'where clause' - Invalid query: SELECT *
FROM `country`
WHERE (`country_id` >0)
ORDER BY `name` ASC
ERROR - 2024-08-19 11:02:29 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\edit.php 87
ERROR - 2024-08-19 11:02:29 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\edit.php 91
ERROR - 2024-08-19 11:02:29 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\edit.php 92
ERROR - 2024-08-19 11:04:18 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 11:04:18 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 11:04:18 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 11:04:21 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 11:04:21 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 11:04:21 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 11:04:22 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 88
ERROR - 2024-08-19 11:04:22 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 92
ERROR - 2024-08-19 11:04:22 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 93
ERROR - 2024-08-19 11:04:22 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 181
ERROR - 2024-08-19 11:04:22 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 185
ERROR - 2024-08-19 11:04:23 --> Query error: Unknown column 'ft.location_id' in 'order clause' - Invalid query: SELECT count(ft.id) as counts
FROM `location` as `ft`
JOIN `state` as `s` ON `s`.`id` = `ft`.`state_id`
JOIN `city` as `ci` ON `ci`.`id` = `ft`.`city_id`
ORDER BY `ft`.`location_id` desc
ERROR - 2024-08-19 11:05:16 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\list.php 91
ERROR - 2024-08-19 11:05:16 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\list.php 95
ERROR - 2024-08-19 11:05:16 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\list.php 96
ERROR - 2024-08-19 11:05:16 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\list.php 188
ERROR - 2024-08-19 11:05:16 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\list.php 192
ERROR - 2024-08-19 11:05:19 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\view.php 170
ERROR - 2024-08-19 11:05:24 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\list.php 91
ERROR - 2024-08-19 11:05:24 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\list.php 95
ERROR - 2024-08-19 11:05:24 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\list.php 96
ERROR - 2024-08-19 11:05:24 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\list.php 188
ERROR - 2024-08-19 11:05:24 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\Location_module\list.php 192
ERROR - 2024-08-19 11:05:29 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 88
ERROR - 2024-08-19 11:05:29 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 92
ERROR - 2024-08-19 11:05:29 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 93
ERROR - 2024-08-19 11:05:29 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 181
ERROR - 2024-08-19 11:05:29 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 185
ERROR - 2024-08-19 11:05:33 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 88
ERROR - 2024-08-19 11:05:33 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 92
ERROR - 2024-08-19 11:05:33 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 93
ERROR - 2024-08-19 11:05:33 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 181
ERROR - 2024-08-19 11:05:33 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\City_module\list.php 185
ERROR - 2024-08-19 11:05:35 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 11:05:35 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 11:05:35 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 11:05:37 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\edit.php 90
ERROR - 2024-08-19 11:05:37 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\edit.php 94
ERROR - 2024-08-19 11:05:37 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\master\State_module\edit.php 95
ERROR - 2024-08-19 11:06:38 --> Query error: Unknown column 's.state_name' in 'field list' - Invalid query: SELECT `ft`.*, `pt`.`name` as `property_type_name`, `pst`.`name` as `property_sub_type_name`, `pa`.`name` as `property_age_name`, `bt`.`name` as `bhk_type_name`, `pft`.`name` as `plot_facing_type_name`, `dft`.`name` as `door_facing_type_name`, `gct`.`name` as `gated_community_type_name`, `s`.`state_name`, `ci`.`city_name`, `l`.`location_name`, `l`.`pincode`, (select au.admin_user_name from admin_user as  au where au.admin_user_id = ft.added_by) as added_by_name, (select au.admin_user_name from admin_user as  au where au.admin_user_id = ft.updated_by) as updated_by_name
FROM `property` as `ft`
LEFT JOIN `property_type` as `pt` ON `pt`.`id` = `ft`.`property_type_id`
LEFT JOIN `property_sub_type` as `pst` ON `pst`.`id` = `ft`.`property_sub_type_id`
LEFT JOIN `property_age` as `pa` ON `pa`.`id` = `ft`.`property_age_id`
LEFT JOIN `bhk_type` as `bt` ON `bt`.`id` = `ft`.`bhk_type_id`
LEFT JOIN `facing_type` as `pft` ON `pft`.`id` = `ft`.`plot_facing_type_id`
LEFT JOIN `facing_type` as `dft` ON `dft`.`id` = `ft`.`door_facing_type_id`
LEFT JOIN `gated_community_type` as `gct` ON `gct`.`id` = `ft`.`gated_community_type_id`
LEFT JOIN `state` as `s` ON `s`.`state_id` = `ft`.`state_id`
LEFT JOIN `city` as `ci` ON `ci`.`city_id` = `ft`.`city_id`
LEFT JOIN `location` as `l` ON `l`.`location_id` = `ft`.`location_id`
WHERE `ft`.`status` = 1
AND `ft`.`is_display` = 1
ORDER BY `ft`.`id` desc
 LIMIT 10
ERROR - 2024-08-19 11:09:19 --> Query error: Unknown column 'state_id' in 'where clause' - Invalid query: SELECT *
FROM `state`
WHERE (`state_id` >0 and `status` = 1 and `is_display` = 1)
ORDER BY `state_name` ASC
ERROR - 2024-08-19 11:10:42 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\search_results.php 24
ERROR - 2024-08-19 11:10:42 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\search_results.php 28
ERROR - 2024-08-19 11:10:42 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\search_results.php 29
ERROR - 2024-08-19 11:10:51 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\search_results.php 24
ERROR - 2024-08-19 11:10:51 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\search_results.php 28
ERROR - 2024-08-19 11:10:51 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\search_results.php 29
ERROR - 2024-08-19 11:10:57 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\search_results.php 24
ERROR - 2024-08-19 11:10:57 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\search_results.php 28
ERROR - 2024-08-19 11:10:57 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\search_results.php 29
ERROR - 2024-08-19 11:12:08 --> Query error: Unknown column 'state_id' in 'where clause' - Invalid query: SELECT *
FROM `state`
WHERE (`state_id` >0)
ORDER BY `state_name` ASC
ERROR - 2024-08-19 11:13:14 --> Query error: Unknown column 's.state_name' in 'field list' - Invalid query: SELECT `ft`.*, `pt`.`name` as `property_type_name`, `pst`.`name` as `property_sub_type_name`, `pa`.`name` as `property_age_name`, `bt`.`name` as `bhk_type_name`, `pft`.`name` as `plot_facing_type_name`, `dft`.`name` as `door_facing_type_name`, `gct`.`name` as `gated_community_type_name`, `s`.`state_name`, `ci`.`city_name`, `l`.`location_name`, `l`.`pincode`, `s`.`name` as `state_name`, `ci`.`name` as `city_name`, `l`.`name` as `location_name`, (select au.name from admin_user as  au where au.id = ft.added_by) as added_by_name, (select au.name from admin_user as  au where au.id = ft.updated_by) as updated_by_name
FROM `property` as `ft`
LEFT JOIN `property_type` as `pt` ON `pt`.`id` = `ft`.`property_type_id`
LEFT JOIN `property_sub_type` as `pst` ON `pst`.`id` = `ft`.`property_sub_type_id`
LEFT JOIN `property_age` as `pa` ON `pa`.`id` = `ft`.`property_age_id`
LEFT JOIN `bhk_type` as `bt` ON `bt`.`id` = `ft`.`bhk_type_id`
LEFT JOIN `facing_type` as `pft` ON `pft`.`id` = `ft`.`plot_facing_type_id`
LEFT JOIN `facing_type` as `dft` ON `dft`.`id` = `ft`.`door_facing_type_id`
LEFT JOIN `gated_community_type` as `gct` ON `gct`.`id` = `ft`.`gated_community_type_id`
LEFT JOIN `state` as `s` ON `s`.`id` = `ft`.`state_id`
LEFT JOIN `city` as `ci` ON `ci`.`id` = `ft`.`city_id`
LEFT JOIN `location` as `l` ON `l`.`id` = `ft`.`location_id`
ORDER BY `ft`.`id` desc
 LIMIT 999999999
ERROR - 2024-08-19 11:14:13 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:14:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:14:17 --> Severity: Notice --> Undefined property: stdClass::$module_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\view.php 48
ERROR - 2024-08-19 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\edit.php 305
ERROR - 2024-08-19 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\edit.php 309
ERROR - 2024-08-19 11:15:09 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\edit.php 310
ERROR - 2024-08-19 11:15:09 --> Query error: Unknown column 'ft.city_name' in 'order clause' - Invalid query: SELECT `ft`.*
FROM `city` as `ft`
WHERE `ft`.`status` = 1
AND `ft`.`state_id` = '1'
ORDER BY `ft`.`city_name` ASC
ERROR - 2024-08-19 11:15:09 --> Query error: Unknown column 'ft.location_name' in 'order clause' - Invalid query: SELECT `ft`.*
FROM `location` as `ft`
WHERE `ft`.`status` = 1
AND `ft`.`city_id` = '1'
ORDER BY `ft`.`location_name` ASC
ERROR - 2024-08-19 11:15:49 --> Query error: Unknown column 'ft.city_name' in 'order clause' - Invalid query: SELECT `ft`.*
FROM `city` as `ft`
WHERE `ft`.`status` = 1
AND `ft`.`state_id` = '1'
ORDER BY `ft`.`city_name` ASC
ERROR - 2024-08-19 11:15:49 --> Query error: Unknown column 'ft.location_name' in 'order clause' - Invalid query: SELECT `ft`.*
FROM `location` as `ft`
WHERE `ft`.`status` = 1
AND `ft`.`city_id` = '1'
ORDER BY `ft`.`location_name` ASC
ERROR - 2024-08-19 11:17:29 --> Query error: Unknown column 'ft.location_name' in 'order clause' - Invalid query: SELECT `ft`.*
FROM `location` as `ft`
WHERE `ft`.`status` = 1
AND `ft`.`city_id` = '1'
ORDER BY `ft`.`location_name` ASC
ERROR - 2024-08-19 11:17:52 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:17:52 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:21:19 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:21:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:28:19 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:28:30 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:28:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:28:46 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 11:28:46 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\xpe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 13:25:04 --> Severity: Notice --> Undefined variable: property_data_more E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:25:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:26:22 --> Severity: Notice --> Undefined variable: property_data_more E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:27:26 --> Severity: Notice --> Undefined variable: property_data_more E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:27:26 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:27:37 --> Severity: Notice --> Undefined variable: property_data_more E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:27:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:28:05 --> Severity: Notice --> Undefined variable: property_data_more E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:28:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:28:15 --> Severity: Notice --> Undefined variable: property_data_more E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:28:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:29:39 --> Severity: Notice --> Undefined variable: property_data_more E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:29:45 --> Severity: Notice --> Undefined variable: property_data_more E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:30:30 --> Severity: Notice --> Undefined variable: property_data_more E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:30:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:32:13 --> Severity: Notice --> Undefined variable: property_data_more E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:32:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:33:23 --> Severity: Notice --> Undefined variable: property_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 13:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\template\load_more_property.php 1
ERROR - 2024-08-19 15:37:05 --> Severity: Notice --> Undefined variable: user_role_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\human_resource\Admin_user_module\list.php 90
ERROR - 2024-08-19 15:38:22 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 15:38:22 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 15:38:22 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 15:38:24 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 88
ERROR - 2024-08-19 15:38:24 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 92
ERROR - 2024-08-19 15:38:24 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 93
ERROR - 2024-08-19 15:38:24 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 181
ERROR - 2024-08-19 15:38:24 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 185
ERROR - 2024-08-19 15:38:25 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 15:38:25 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 15:38:25 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 15:38:30 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\edit.php 90
ERROR - 2024-08-19 15:38:30 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\edit.php 94
ERROR - 2024-08-19 15:38:30 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\edit.php 95
ERROR - 2024-08-19 15:38:37 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 88
ERROR - 2024-08-19 15:38:37 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 92
ERROR - 2024-08-19 15:38:37 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 93
ERROR - 2024-08-19 15:38:37 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 181
ERROR - 2024-08-19 15:38:37 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 185
ERROR - 2024-08-19 15:38:46 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 15:38:46 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 15:38:46 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 15:38:48 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\edit.php 90
ERROR - 2024-08-19 15:38:48 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\edit.php 94
ERROR - 2024-08-19 15:38:48 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\edit.php 95
ERROR - 2024-08-19 15:38:57 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 93
ERROR - 2024-08-19 15:38:57 --> Severity: Notice --> Undefined property: stdClass::$country_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 97
ERROR - 2024-08-19 15:38:57 --> Severity: Notice --> Undefined property: stdClass::$country_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\State_module\list.php 98
ERROR - 2024-08-19 15:39:08 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 88
ERROR - 2024-08-19 15:39:08 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 92
ERROR - 2024-08-19 15:39:08 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 93
ERROR - 2024-08-19 15:39:08 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 88
ERROR - 2024-08-19 15:39:08 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 92
ERROR - 2024-08-19 15:39:08 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 93
ERROR - 2024-08-19 15:39:08 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 181
ERROR - 2024-08-19 15:39:08 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\City_module\list.php 185
ERROR - 2024-08-19 15:39:54 --> Severity: Notice --> Undefined variable: user_role_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\human_resource\Admin_user_module\list.php 90
ERROR - 2024-08-19 15:40:28 --> Severity: Notice --> Undefined variable: user_role_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\human_resource\Admin_user_module\list.php 90
ERROR - 2024-08-19 15:41:56 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 91
ERROR - 2024-08-19 15:41:56 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 95
ERROR - 2024-08-19 15:41:56 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 96
ERROR - 2024-08-19 15:41:56 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 91
ERROR - 2024-08-19 15:41:56 --> Severity: Notice --> Undefined property: stdClass::$state_id E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 95
ERROR - 2024-08-19 15:41:56 --> Severity: Notice --> Undefined property: stdClass::$state_name E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 96
ERROR - 2024-08-19 15:41:56 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 188
ERROR - 2024-08-19 15:41:56 --> Severity: Notice --> Undefined variable: is_display E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\master\Location_module\list.php 192
ERROR - 2024-08-19 15:42:20 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:42:20 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:42:55 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:44:24 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:44:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:49:37 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:50:16 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:50:16 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:56:45 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 15:56:45 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 16:17:00 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 16:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 17:31:02 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 17:31:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 17:31:49 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 17:31:49 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 17:35:39 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 17:35:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 17:55:22 --> Severity: error --> Exception: syntax error, unexpected '{' E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\User.php 748
ERROR - 2024-08-19 17:55:22 --> Severity: error --> Exception: syntax error, unexpected '{' E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\User.php 748
ERROR - 2024-08-19 17:55:22 --> Severity: error --> Exception: syntax error, unexpected '{' E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\User.php 748
ERROR - 2024-08-19 17:55:26 --> Severity: error --> Exception: syntax error, unexpected '{' E:\xampp\htdocs\xampp\MARS\pe_realtors\application\controllers\User.php 748
ERROR - 2024-08-19 18:20:36 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 18:20:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 18:51:06 --> Severity: Notice --> Undefined variable: description E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\enquiry\Enquiry_module\edit.php 138
ERROR - 2024-08-19 18:52:01 --> Severity: Notice --> Undefined variable: description E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\enquiry\Enquiry_module\edit.php 138
ERROR - 2024-08-19 19:55:51 --> Severity: Notice --> Undefined variable: country_data E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
ERROR - 2024-08-19 19:55:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\xampp\MARS\pe_realtors\application\views\secureRegions\catalog\Property_module\list.php 84
