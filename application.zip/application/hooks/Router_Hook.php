<?

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Router_Hook
{
	/**
	 * Loads routes from database.
	 *
	 * @access public
	 * @params array : hostname, username, password, database, db_prefix
	 * @return void
	 */
	function get_routes($params)
	{
		return;

	}
}

?>