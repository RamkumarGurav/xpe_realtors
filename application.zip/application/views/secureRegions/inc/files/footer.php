<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="<?php echo _lte_files_ ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo _lte_files_ ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo _lte_files_ ?>dist/js/adminlte.js"></script>

<!-- overlayScrollbars -->
<script src="<?php echo _lte_files_ ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="<?php echo _lte_files_ ?>dist/js/demo.js"></script>
<script src="<?php echo _lte_files_ ?>plugins/pace-progress/pace.min.js"></script>
<!-- PAGE PLUGINS -->
<!-- jQuery Mapael -->
<script src="<?php echo _lte_files_ ?>plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
<script src="<?php echo _lte_files_ ?>plugins/raphael/raphael.min.js"></script>
<script src="<?php echo _lte_files_ ?>plugins/jquery-mapael/jquery.mapael.min.js"></script>
<script src="<?php echo _lte_files_ ?>plugins/jquery-mapael/maps/usa_states.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo _lte_files_ ?>plugins/chart.js/Chart.min.js"></script>

<!-- PAGE SCRIPTS -->
<script src="<?php echo _lte_files_ ?>dist/js/pages/dashboard2.js"></script>


<script src="<?php echo _lte_files_ ?>js/alert.js"></script>

<script src="<?php echo _lte_files_ ?>js/common.js"></script>
<div id="base_url_function" style="display:none"><?php echo MAINSITE_Admin ?></div>
<script src="<?php echo _lte_files_ ?>js/function.js"></script>