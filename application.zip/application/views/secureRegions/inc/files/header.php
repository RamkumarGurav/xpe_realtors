<!-- Font Awesome Icons -->
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/fontawesome-free/css/all.min.css">
<!-- overlayScrollbars -->
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/overlayScrollbars/css/OverlayScrollbars.min.css">

<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/pace-progress/themes/black/pace-theme-flat-top.css">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo _lte_files_ ?>dist/css/adminlte.min.css">

<link rel="stylesheet" href="<?php echo _lte_files_ ?>dist/css/custome.css">
<!-- Google Font: Source Sans Pro -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">