<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/fontawesome-free/css/all.min.css">
<!-- Ionicons -->
<?php  /*?><link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"><?php  */ ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<?php  /*?>  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/fixedheader/3.1.2/css/fixedHeader.dataTables.min.css"><?php  */ ?>

<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
<link rel="stylesheet"
  href="<?php echo _lte_files_ ?>plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/summernote/summernote-bs4.css">
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/pace-progress/themes/black/pace-theme-flat-top.css">
<link rel="stylesheet" href="<?php echo _lte_files_ ?>dist/css/custome.css">
<link rel="stylesheet" href="<?php echo _lte_files_ ?>css/jquery-ui-12.min.css">
<script src="<?php echo _lte_files_ ?>plugins/jquery/jquery.min.js"></script>
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/select2/css/select2.min.css">
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<!-- Toastr -->
<link rel="stylesheet" href="<?php echo _lte_files_ ?>plugins/toastr/toastr.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo _lte_files_ ?>dist/css/adminlte.min.css">
<!-- Google Font: Source Sans Pro -->
<?php  /*?><link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet"><?php  */ ?>
<style type="text/css">
  #example1 thead th {
    position: sticky;
    top: 56px;
    background-color: #fff;
  }
</style>