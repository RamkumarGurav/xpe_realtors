<script type="text/javascript" src="ckeditor.js"></script>
<textarea class="ckeditor" name="editor"></textarea>